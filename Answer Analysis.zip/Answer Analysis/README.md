# Voice-Assistant
- A voice assistant built using HTML, CSS and JavaScript, which uses Speech to Text and Speech Utterance features from Web Speech API. 
- When the user speaks, the message is displayed on the chat interface and a voice response based on that is generated from the assistant.
