# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 10:18:33 2023

@author: Dhanya
"""
import torch
from bert_score import score
from transformers import pipeline as p
from sentence_transformers import SentenceTransformer
import nltk
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.bleu_score import corpus_bleu
import openpyxl
import numpy as np
import pandas as pd
import bert_score.utils as u
def sBert(target,ans):
    sentence_transformer_model = SentenceTransformer('bert-base-nli-mean-tokens')
    if isinstance(target, str):
       target = [target]
    if isinstance(ans, str):
       ans = [ans]
    # print("yes")
    sentence_embeddings = sentence_transformer_model.encode(target)
    sentence_embeddings2 = sentence_transformer_model.encode(ans)
    # print("yes")
    cos = torch.nn.CosineSimilarity(dim=1, eps=1e-6)
    output = torch.mean(cos(torch.tensor(sentence_embeddings), torch.tensor(sentence_embeddings2))).item()
    return output

def calculate_bleu_score(target, ans):
    print(target, ans)
    org=[]
    org.append(target.split())
    giv=ans.split()
   # print(org)
   # print(giv)
  #  reference_tokens = nltk.word_tokenize(ans.lower())
  #  candidate_tokens = nltk.word_tokenize(target.lower())
    score = sentence_bleu(org,giv)
    return score

def relevance(row_num):
    print(row_num)
    ws= openpyxl.load_workbook('QandAns.xlsx')
    sheet1 = ws['Sheet1']
    row=sheet1.max_row
    target=sheet1.cell(row=row_num,column=2).value
    ans=sheet1.cell(row=row_num,column=3).value
    print(target,ans)
    bert_score=sBert(target,ans)
    print(bert_score)
    bleu_score = calculate_bleu_score(target, ans)
    print(bleu_score)
    sheet1.cell(row=row_num,column=4,value=bert_score)
    sheet1.cell(row=row_num,column=5,value=bleu_score)
    ws.save('QandAns.xlsx')
     
    