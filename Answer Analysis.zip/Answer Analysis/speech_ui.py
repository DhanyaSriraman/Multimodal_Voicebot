# -*- coding: utf-8 -*-
from flask import Flask, render_template, request
import gtts  
from playsound import playsound  
import numpy as np
import os
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import openpyxl
from sklearn.model_selection import train_test_split
import speech_recognition as sr
import time
import signal
import random
import subprocess
def signal_handler(sig, frame):
    os._exit(1)

signal.signal(signal.SIGINT, signal_handler)

app = Flask(__name__,template_folder='D:/FacQA/Answer Analysis')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])


def run_code():
    text="Welcome! Lets get you prepared for your interview. Lets start with your behavioural questions"
    t= gtts.gTTS(text)
    t.save("greet.mp3")
    playsound("greet.mp3")
    
    used_rows_tech = set()
    
    ws1=openpyxl.load_workbook('D:/Prediction-of-Job-Interview-Performance-by-extracting-Lexical-features-/ques_only.xlsx')
    sheet = ws1['Sheet1']
    row1=sheet.max_row
    results = ''
    for i in  range(1,row1+1):
            os.remove("welcome.mp3")
            text=sheet.cell(row=i,column=1).value
            t1 = gtts.gTTS(text)  
            t1.save("welcome.mp3")   
            playsound("welcome.mp3")
            r = sr.Recognizer()
            mic = sr.Microphone()
           # time.sleep(20)
            try:
                with mic as source2:
                    print("Inside mic")
                    r.adjust_for_ambient_noise(source2,duration=1)
                   # r.energy_threshold = 50000
                    audio2 = r.listen(source2)
                    MyText = r.recognize_google(audio2)
                    MyText = MyText.lower()
                    print(MyText)
                    if(len(MyText)==0):
                     sheet.cell(row=i,column=2,value=" ")
                    else:
                     sheet.cell(row=i,column=2,value=MyText)
                    results += "Did you say " + MyText + "<br>"
                  #  with open(f"audio_{i}.wav", "wb") as f:
                      #  f.write(audio2.get_wav_data())
            except sr.RequestError as e:
                results += "Could not request results; {0}".format(e) + "<br>"
            except sr.UnknownValueError:
                results += "unknown error occurred" + "<br>"
            except KeyboardInterrupt:
                print("Interupted")
                pass
            ws1.save('D:/Prediction-of-Job-Interview-Performance-by-extracting-Lexical-features-/ques_only.xlsx')
    ws1.close()
    import sys
    sys.path.append('D:/Prediction-of-Job-Interview-Performance-by-extracting-Lexical-features-')
    from speech_features import feature_extraction
    from behavioural_lexical_analysis import run_func
    feature_extraction()
    run_func()
    
    text="Okay!Lets move on to your technical round now!!"
    t= gtts.gTTS(text)
    t.save("greet1.mp3")
    playsound("greet1.mp3")
    
    ws= openpyxl.load_workbook('QandAns.xlsx')
    sheet1 = ws['Sheet1']
    row=sheet1.max_row
    results = ''
    
    for i in range (1,3): # change to i in the range of 1,10
        os.remove("welcome.mp3")
        row_num = random.randint(1, row)
        while row_num in used_rows_tech:
            row_num = random.randint(1,row)
        used_rows_tech.add(row_num)
        text=sheet1.cell(row=row_num,column=1).value
        t1 = gtts.gTTS(text)  
        t1.save("welcome.mp3")   
        playsound("welcome.mp3")
        r = sr.Recognizer()
        mic = sr.Microphone()
        time.sleep(20)
        try:
            with mic as source2:
                print("Inside mic")
                r.adjust_for_ambient_noise(source2,duration=1)
               # r.energy_threshold = 50000
                audio2 = r.listen(source2,phrase_time_limit=5)
                MyText = r.recognize_google(audio2)
                MyText = MyText.lower()
                print(MyText)
                if(len(MyText)==0):
                 sheet1.cell(row=row_num,column=3,value=" ")
                else:
                 sheet1.cell(row=row_num,column=3,value=MyText)
                results += "Did you say " + MyText + "<br>"
              #  with open(f"audio_{i}.wav", "wb") as f:
                  #  f.write(audio2.get_wav_data())
        except sr.RequestError as e:
            results += "Could not request results; {0}".format(e) + "<br>"
        except sr.UnknownValueError:
            results += "unknown error occurred" + "<br>"
        except KeyboardInterrupt:
            print("Interupted")
            break
        ws.save('QandAns.xlsx')
        import ans_sim as f1
        f1.relevance(row_num)
        ws =openpyxl.load_workbook('QandAns.xlsx')
        sheet1 = ws['Sheet1']
    ws.close()
    
    text="You have successfullyn completed your interview session! Lets look at your feedback"
    t= gtts.gTTS(text)
    t.save("greet1.mp3")
    playsound("greet1.mp3")
    
    return results

if __name__ == '__main__':
    try:
      app.run()
    except KeyboardInterrupt:
        print("Interupted")
        pass